<?php
/**
 * Plugin Name: Excel Sheet Format
 * Plugin URI: http://google.com/
 * Description: Read excels made easy
 * Version: 1.0
 * Author: Just Trials
 * Author URI: http://google.com
 * License: GPL3
 * Network: true
 * Text Domain: read-excel
 */

define('exlURL', plugins_url('excelread/'));


   class XLS {

     static function createTable(){
       require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
       global $wpdb;
        $table_name = $wpdb->prefix . "excel_formats";
        $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
        `ID` int(10) NOT NULL AUTO_INCREMENT,
        `userID` int(10) NOT NULL,
        `postID` int(10) NOT NULL,        
        `headings` text NOT NULL,
        `columns` text NOT NULL,        
         PRIMARY KEY (`ID`)
         )";
       dbDelta($sql);
       $table_second = $wpdb->prefix . "excel_formats_data";
       $sql1 = "CREATE TABLE IF NOT EXISTS `$table_second` (
        `ID` int(10) NOT NULL AUTO_INCREMENT,
        `userID` int(10) NOT NULL,
        `postID` int(10) NOT NULL,        
        `Contents` text NOT NULL,
        `formID` int(10) NOT NULL,        
         PRIMARY KEY (`ID`)
         )";
        dbDelta($sql1);
     }

      static function myexcelform(){

        $formUp = '<form enctype="multipart/form-data" action="import.php" method="post">
                  <input type="hidden" name="MAX_FILE_SIZE" value="2000000" />
                  <table width="600">
                  <tr>
                  <td>Names file:</td>
                  <td><input type="file" name="file" /></td>
                  <td><input type="submit" value="Upload" /></td>
                  </tr>
                  </table>
                  </form>';
        echo $formUp;

      }
      static function xlsTable($atts){

        extract( shortcode_atts( array(
          'formatid' => 'noID',
        ), $atts, 'xls-format' ) ); 
        global $wpdb;
        $table_name = $wpdb->prefix . "excel_formats";
        $a = $wpdb->get_results("SELECT * from $table_name where ID=$formatid",ARRAY_A);  
        //print_r($a);
        $heads = explode(',', $a[0]['headings']);
        $cols =  explode(',', $a[0]['columns']);
        $haspostid = get_the_ID();
        $hasUserId = get_current_user_id();
        $content = '';
        if($hasUserId != "0" && $haspostid != ""){
          $table_name2 = $wpdb->prefix . "excel_formats_data"; 
          $myxlstabledata =  $wpdb->get_results("SELECT Contents from $table_name2 where formID=$formatid AND postID=$haspostid AND userID=$hasUserId",ARRAY_A);
           
           if($myxlstabledata){
              $content = unserialize($myxlstabledata[0]['Contents']); 
              }
          $mytable = '<div class="xlsTable"> <form action="" method="post"> <table>';
          $mytable .= '<tr>';
          foreach($heads as $val){
            $mytable .= '<th style="text-align:center;">' . $val . '</th>'; 
          }
          $mytable .= '</tr>';

          $totalCols = count($heads);
          foreach($cols as $val){
            $mytable .= '<tr> <td>' . $val . '</td>';
            for($i=1; $i<$totalCols; $i++){
              if(is_array($content))
                $vall = $content[$val][$i];
              else
                $vall = "";
                
              $mytable .= '<td><input value="' . $vall . '" style="width: 100px;" type="text" name="' . $val . '[' . $i .']" readonly/></td>';
            }
            $mytable .=  '</tr>'; 
          }
          $mytable .= ' </table>';
          
          $mytable .= '<input id="myexcel-table-edit-button-unique" type="button" value="Edit table"><input type="button" id="myexcel-table-submit-button-unique" style="display:none;" value="submit Data">'; 
          $mytable .= '<span class="xlsFormatInfo" style="display:none;" formid="'.$formatid.'" userid="'.$hasUserId.'" postid="' . $haspostid. '"> info</span>';
          $mytable .= '</form></div>'; 

        }
        else{

          $mytable = '<div class="xlsTable"> <form action="" method="post"> <table>';
          $mytable .= '<tr>';
          foreach($heads as $val){
            $mytable .= '<th style="text-align:center;">' . $val . '</th>'; 
          }
          $mytable .= '</tr>';

          $totalCols = count($heads);
          foreach($cols as $val){
            $mytable .= '<tr> <td>' . $val . '</td>';
            for($i=1; $i<$totalCols; $i++){
              $mytable .= '<td><input style="width: 100px;" type="text" name="' . $val . '[' . $i .']" readonly/></td>';
            }
            $mytable .=  '</tr>'; 
          }
          $mytable .= ' </table>';
          
          $mytable .= '<span class="xlsText"> *Please Login to Add and Edit table Data.</span>';
          
          $mytable .= '</form></div>';          
        }
        

        echo $mytable;
      }

      static function adminMenu(){

       add_plugins_page('Excel', 'XLS settings', 'manage_options', 'excelread/import.php', '');      
       add_plugins_page('Excel-SC', 'XLS shortcodes', 'manage_options', 'excelread/available-sc.php', '');      

     }

      

      static function addEditJS(){
     
        wp_enqueue_script( 'adding-edit-js', plugins_url() . '/excelread/edit.js', array(), '1.0.0', true );
        wp_localize_script('adding-edit-js', 'XLS', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nextNonce' => wp_create_nonce('myajax-next-nonce'))
            );
      }
      static function saveXlsTableData(){
       global $wpdb;
        $form = $_POST['formid'];
        $user = $_POST['userid'];
        $post = $_POST['postid'];
        parse_str($_POST['mydata'], $myformdata);
        $mycontents = serialize($myformdata);
        $table_name2 = $wpdb->prefix . "excel_formats_data"; 
        $myxlstabledata =  $wpdb->get_results("SELECT ID from $table_name2 where formID=$form AND postID=$post AND userID=$user",ARRAY_A);
        if($myxlstabledata){
          $wpdb->query("UPDATE $table_name2 SET Contents = '$mycontents' where formID=$form AND postID=$post AND userID=$user");
        } 
        else{
          $args = array('formID' =>$form, 'postID' =>$post, 'userID' =>$user , 'Contents'=>$mycontents  );
          $wpdb->insert($table_name2, $args);
        }     
        die;
      }

      static function getXlsTableData(){
        
      }

   }
    
   add_action("init", "XLS::createTable");
   add_action("admin_menu", "XLS::adminMenu");
   add_shortcode('xls-format', 'XLS::xlsTable');
   add_action( 'wp_enqueue_scripts', 'XLS::addEditJS' );
   add_action('wp_ajax_saveXlsTableData', 'XLS::saveXlsTableData');
   add_action('wp_ajax_nopriv_saveXlsTableData', 'XLS::saveXlsTableData');
   add_action('wp_ajax_getXlsTableData', 'XLS::getXlsTableData');
   add_action('wp_ajax_nopriv_getXlsTableData', 'XLS::getXlsTableData');

?>

