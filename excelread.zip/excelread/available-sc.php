
<div class="available-shortcodes" style="margin-top:150px; margin-left:150px;">
	<?php 
	  global $wpdb;
	  $table_name = $wpdb->prefix . "excel_formats";
	  $formats = $wpdb->get_results("SELECT ID FROM $table_name where 'Contents' != ''", ARRAY_A);
      if($formats){
      	$i=1;
      	$mn = "mFormatName";
      	echo '<div class="shortcodes"><h2>Available shortcodes Are :</h2><table><tr> <th> Sr.No. </th><th> Format Name </th><th> Shortcode</th></tr>';
        foreach($formats as $formid)
        {
        	 echo '<tr><td>' . $i . '</td><td>' .$mn. '</td><td>[xls-format formatid="' .$formid['ID']. '"]</td></tr>';
        }
        echo "</table></div>";
      }
      else{
      	echo '<div class="not-found"> <span> Sorry, No any shortcode is available at the moment.</span><br/><span> Upload table formats (only .xls files) to generate shortcodes</span></div>';
      }
	?>
</div>

<style>
.shortcodes td{
	text-align: center;
	background-color: rgb(132, 255, 255);
	font-size: 20px;
	font-family: comic sans ms;
	line-height: 25px;
}
.shortcodes table{
	min-width: 600px;
}
.shortcodes th{
  background-color: rgb(255, 100, 23);
  font-size: 25px;
  font-family: georgia;
  line-height: 30px;
}
</style>
