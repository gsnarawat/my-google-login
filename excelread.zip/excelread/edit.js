jQuery(document).ready(function($){

	jQuery("#myexcel-table-edit-button-unique").click(function(){
      
      
    jQuery(this).hide();	  
	  jQuery(this).parent('form').find('input[type="text"]').each(function(){
         jQuery(this).removeAttr('readonly');
	  });
	  jQuery(this).parent('form').find("#myexcel-table-submit-button-unique").show();

	});

	

	jQuery("#myexcel-table-submit-button-unique").click(function(){
      
      mydata = jQuery(this).parent('form').serialize();
      postid = jQuery(this).parent('form').find('span.xlsFormatInfo').attr('postid');
      userid = jQuery(this).parent('form').find('span.xlsFormatInfo').attr('userid');
      formid = jQuery(this).parent('form').find('span.xlsFormatInfo').attr('formid');
      myelement = jQuery(this);
      jQuery.post(
           XLS.ajaxurl,
            {
                action: 'saveXlsTableData',                
                mydata: mydata,
                postid: postid,
                userid: userid,
                formid: formid,
                nextNonce: XLS.nextNonce
            },
     function(response) {
        if (response === 'Busted!'){
          alert("You don't have Access.");
          return false;
        }
        else{
         alert("Table Updated Succesfully");
        } 
        jQuery(myelement).hide();
        jQuery(myelement).parent('form').find("#myexcel-table-edit-button-unique").show();
        jQuery(myelement).parent('form').find('input[type="text"]').each(function(){
         jQuery(this).attr('readonly','');
        });

        
     });
      //jQuery(this).hide();
	  //console.log(jQuery(this).parent('form').elements)
	  //jQuery(this).parent('form').find('input[type="text"]').each(function(){
         //jQuery(this).removeAttr('readonly');
	  //});

	  //jQuery(this).parent('form').find("#myexcel-table-submit-button-unique").show();

	});





});