<?php

if(isset($_POST['submit']) && $_POST['submit']=='Upload'){

      include 'excel_reader.php';
      $excel = new PhpExcelReader;

      function sheetData($sheet) { 
      
      $rows = '';
      $cols = '';
      $numberofrows = $sheet['numRows'];
      $numberofcols = $sheet['numCols'];
      $values_array = $sheet['cells'];
      foreach($values_array as $key=>$value){
         
         if($key=='1')
         {
           if(is_array($value)){
              foreach($value as $p){
               $rows .= $p . ',';
              }
           }

         }

         else{

           if(is_array($value) && $value['1']) 
            $cols .= $value['1'] . ',';  
         }
         
       }  
      $headings = substr($rows, 0, -1);
      $columns = substr($cols, 0, -1);
      $args = array('userID'=>'1', 'headings'=>$headings, 'columns'=> $columns, 'postID' => '0');
      global $wpdb;
      $table_name = $wpdb->prefix . "excel_formats";
      $wpdb->insert($table_name, $args);
      }

       if ( $_FILES['file']['tmp_name'])
        {
         $excel->read( $_FILES['file']['tmp_name']);
          sheetData($excel->sheets[0]); 
         }
      else{

           $msg = '<div style="margin-top: 65px;"class="updated" id="message"><p>No any File chosen or File is <strong>invalid!</strong></p></div>';
            echo $msg;
          }   
    
  die;
 }


?>


  <form enctype="multipart/form-data" action="" method="post" style="margin-top:150px; margin-left:150px;">
    <input type="hidden" name="MAX_FILE_SIZE" value="2000000" />
    <table width="600">
      <tr>
        <td>Names file:</td>
        <td><input type="file" name="file" accept="application/vnd.ms-excel"/></td>
        <td><input type="submit" value="Upload" name="submit"/></td>
      </tr>
    </table>
  </form>
