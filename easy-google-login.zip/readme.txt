=== Plugin Name ===
Contributors: gsnarawat
Tags: google login, wordpress login with google, signup with google, login and register with google, custom google login
Requires at least: 3.0.1
Tested up to: 3.8
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Version: 1.0

Login with google and Register with wordpress.

== Description ==

 1. This Plugin lets you Add a functionality to your Wordpress Blog/Site to Login with Google account and Register in Wordpress.
  
 2. A page into Wordpress Admin section to mange everything, like your Google app Client ID, page after loggin in, etc.
 
 3. Simple Plugin no Complexity in Installation and no extra overloads to existing site.
 
 4. Simple Shortcode to place anywhere, from where you want to get your Users Intraction for logging in with Google.

== Installation ==


1. Upload easy-google-login to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress Admin
3. Go to Settings menu with this Plugin
4. Enter your Google Client ID and choose other options.
5. Put '[easy-google-login]' shortcode anywhere you want to put the login button. 

== Frequently Asked Questions ==
give me a mail at gopalnarawat@gmail.com



== Screenshots ==

Not yet available.

== Changelog ==

= 1.0 =
* Just an Initial Push.

