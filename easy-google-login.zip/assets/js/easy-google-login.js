


  /**

   * Global variables to hold the profile and email data.
   */

   jQuery("#EGLloginButton").click(function(){
   
    var myParams = {
      'clientid' : EGL.client_id,
      'cookiepolicy' : 'none',
      'callback' : 'EGLloginFinishedCallback',
      'scope' : 'https://www.googleapis.com/auth/plus.profile.emails.read',
      'requestvisibleactions' : 'http://schemas.google.com/AddActivity'
      // Additional parameters
    };
    gapi.auth.signIn(myParams);


   });

   var profile, email;



  /*
   * Triggered when the user accepts the sign in, cancels, or closes the
   * authorization dialog.
   */
  function EGLloginFinishedCallback(authResult) {
    if (authResult) {
      if (authResult['error'] == undefined){
       // toggleElement('signin-button'); // Hide the sign-in button after successfully signing in the user.
        gapi.client.load('plus','v1', EGLloadProfile);  // Trigger request to get the email address.
      } else {
        console.log('An error occurred');
      }
    } else {
      console.log('Empty authResult');  // Something went wrong
    }
  }

  function EGLloadProfile(){
    var request = gapi.client.plus.people.get( {'userId' : 'me'} );
    request.execute(EGLloadProfileCallback);
  }
  function EGLloadProfileCallback(obj) {
    profile = obj;

    // Filter the emails object to find the user's primary account, which might
    // not always be the first in the array. The filter() method supports IE9+.
    email = obj['emails'].filter(function(v) {
        return v.type === 'account'; // Filter out the primary email
    })[0].value; // get the email from the filtered results, should always be defined.
    EGLdisplayProfile(profile);
  }

  /**
   * Display the user's basic profile information from the profile object.
   */
  function EGLdisplayProfile(profile){
      


     console.log(profile['displayName']);
     console.log(profile['image']['url']);
     console.log(email);

      var args = {};
      args["Name"] = profile['displayName'];
      args["Image"] = profile['image']['url'];
      args["Email"] = email;

     jQuery.post(
            EGL.ajaxurl,
            {
                action: 'EGLlogin',
                dpName: profile['displayName'],
                args: args,
                nextNonce: EGL.nextNonce
            },
     function(response) {
        if (response === 'Busted!')
            return false;

       
       document.location.assign(EGL.afterLogin);
     });

  }
