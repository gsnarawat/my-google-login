<?php 

if (isset($_POST['google-login'])) {

    
        update_option('EGLoginPageAfterLogin_id', $_POST['EGLoginPageAfterLogin'], '', 'yes');
        $aflogin = get_permalink($_POST['EGLoginPageAfterLogin']);        
        update_option('EGLoginAppID', $_POST['EGLoginAppID'], '', 'yes');
        update_option('EGLoginPageAfterLogin', $aflogin, '', 'yes');        
        update_option('EGLoginDefaultRole', $_POST['EGLoginDefaultRole'], '', 'yes');
        update_option('EGLoginGetAvatar', $_POST['EGLoginGetAvatar'], '', 'yes');
        $msg = '<div class="updated" id="message"><p>Settings Saved <strong>Successfully!</strong></p></div>';
    
}
?>
<div class="wrap">
    <h2>My Google Login</h2>
    <?php if (isset($msg)) echo $msg; ?>
    <div class="simpleTabs">
        <ul class="simpleTabsNavigation">
            <li><a href="#">Settings</a></li>
            <li><a href="#">How it Works</a></li>        
        </ul>
        <div class="simpleTabsContent">
            <div class="left-col">
                <form method="POST" action="" name="saveClientID">
                    <dl>
                        <dt><?php _e('Google App ClientID:'); ?></dt>
                        <dd>
                            <input type="text" name="EGLoginAppID" value="<?php echo get_option('EGLoginAppID'); ?>"/>
                            <em><?php _e('Please put your Google app Client id.'); ?></em>
                        </dd>

                        <dt><?php _e('Page After Login:'); ?></dt>
                        <dd>
                            <?php printf(wp_dropdown_pages(array('name' => 'EGLoginPageAfterLogin', 'echo' => 0, 'show_option_none' => __('&mdash; Select &mdash;'), 'option_none_value' => '0', 'selected' => get_option('EGLoginPageAfterLogin_id')))); ?>
                            <em><?php _e('Please select page for after login redirection, For "Home Page" leave it unselected.'); ?></em>
                        </dd>
                        
                        <dt><?php _e('Default Role for Google User:'); ?></dt>
                        <dd>
                            <select name="EGLoginDefaultRole" id="EGLoginDefaultRole">
                                <?php wp_dropdown_roles(get_option('EGLoginDefaultRole')); ?>
                            </select>
                            <em><?php _e('Please select a role for new user registration.'); ?></em>
                        </dd>

                        <dt><?php _e('Get User Avatar From Google:'); ?></dt>
                        <dd>
                            <select name="EGLoginGetAvatar" id="EGLoginGetAvatar">                                
                                <option value="no" <?php if (get_option('EGLoginGetAvatar') == 'no') echo "selected"; ?> >No</option>
                                <option value="yes" <?php if (get_option('EGLoginGetAvatar') == 'yes') echo "selected"; ?>> Yes</option>                                
                            </select>
                            <em><?php _e('Please select yes, if you like to use Google image as wordpress profile image'); ?></em>
                        </dd>
                    </dl>

                    <input type="submit" name="google-login" class="button button-primary button-large" value="Save"/>
                </form>
            </div>
           
                    <div style="clear: both;"></div>
            <hr />
            <h3 class="float_left">Easy Google Login</h3>
           

        </div>
        <div class="simpleTabsContent">

            
            <div style="clear: both;"></div>
            <hr />
            <h3 class="float_left">Easy Google Login</h3>
           
        </div>
    </div>
</div>