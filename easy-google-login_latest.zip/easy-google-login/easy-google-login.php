<?php

/**
 * Plugin Name: Easy Google Login
 * Plugin URI: http://google.com/
 * Description: Simple Plugin for Google Authentication and User Registration Process. 
 * Version: 1.0
 * Author: Gopal Singh
 * Author URI: http://google.com
 * License: GPL3
 * Network: true
 * Text Domain: easy-google-login
 */
	define('EGLURL', plugins_url('easy-google-login/'));

	 class EGL {

		 static function assets(){

		 	wp_enqueue_script("jquery");
		 	$plusonejs = 'https://apis.google.com/js/client:plusone.js';
		    wp_enqueue_script('easy-google-login1', $plusonejs);
		    //wp_localize_script( 'easy-google-login1', 'MyScriptParams', array('parsetags' => 'explicit') );
		    $myGooglLoginJs = EGLURL . 'assets/js/easy-google-login.js';
		    wp_enqueue_script('easy-google-login', $myGooglLoginJs);
		    $myclientid = get_option('EGLoginAppID');
		    $afterLogin = get_option('EGLoginPageAfterLogin', site_url('/'));
		    if($afterLogin == '')
		    	$afterLogin = site_url('/');
		    wp_localize_script('easy-google-login', 'EGL', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'client_id' => $myclientid,
            'afterLogin' => $afterLogin,
            'nextNonce' => wp_create_nonce('myajax-next-nonce'))
            );

		 }

		 static function EGLlogin(){
		  
		   $nonce = $_POST['nextNonce'];
           if (!wp_verify_nonce($nonce, 'myajax-next-nonce'))
             die('Busted!');

            $user_profile = $_POST['args'];
	        
	        $efl_default_role = get_option('EGLoginDefaultRole', 'subscriber');
	        $save_avatar = get_option('EGLoginGetAvatar', 'no');

	        $userdata = array(
	            'user_login' => $user_profile['Name'],
	            'user_nicename' => $user_profile['Name'],
	            'user_email' => $user_profile['Email'],
	            'display_name' => $user_profile['Name'],
	            'first_name' => $user_profile['Name'],
	            'last_name' => $user_profile['Name'],
	            'role' => $efl_default_role,
	            'user_url' => $user_profile['Image'],
	            'user_pass' => "123456"
	        );

	        $user = get_user_by( 'email', $user_profile['Email'] );


	        if (!$user->ID) {
	            $user_id = wp_insert_user($userdata);
	            wp_set_auth_cookie($user_id);
	        } else {
	            wp_set_auth_cookie($user->ID);
	            $user_id = $user->ID;
	        }
	        if ($save_avatar == 'yes') {
	            echo "dfd";
	            $imgthumb = file_get_contents($user_profile['Image']);
	            $imgfull = file_get_contents($user_profile['Image']);
	            $upload = wp_upload_dir();
	            $upload_dir = $upload['basedir'];
	            $avatar_dir = $upload_dir . '/avatars';

	            if (!is_dir($avatar_dir)) {
	                mkdir($avatar_dir, 0777);
	            }
	            $upload_dir = $upload_dir . '/avatars/' . $user_id;

	            if (!is_dir($upload_dir)) {
	                mkdir($upload_dir, 0777);
	            }
	            $filefull = $upload_dir . '/' . $user_profile['Id'] . '-bpfull.jpg';
	            $filethumb = $upload_dir . '/' . $user_profile['Id'] . '-bpthumb.jpg';

	            file_put_contents($filefull, $imgfull);
	            file_put_contents($filethumb, $imgthumb);
	        }




	        exit;
		 }

		 static function EGLloginButton(){
		    
		    
		 	
            if (!is_user_logged_in()){
             echo '<input type="button" id="EGLloginButton" value="Sign In with Google"/>';	
            }
		 	
		  }

		  static function adminAssets() {
	        if (!strpos($_REQUEST['page'], "egl.admin.page.php"))
	            return;
	        $easyFacebookTabsJs = EGLURL . 'assets/js/easy-google-login-tabs.js';
	        wp_enqueue_script('my-google-tabs', $easyFacebookTabsJs);

	        $easyFacebookTabsCSS = EGLURL . 'assets/css/easy-google-login-tabs.css';
	        wp_enqueue_style('my-google-tabs', $easyFacebookTabsCSS);
	    }
		  static function adminMenu(){

		   add_plugins_page('My Google Login', 'Google Login settings', 'manage_options', 'easy-google-login/egl.admin.page.php', '');		 	

		 }

		 static function plugin_action($links, $file) {
	        static $my_plugin;
	        if (!$my_plugin) {
	            $my_plugin = plugin_basename(__FILE__);
	        }
	        if ($file == $my_plugin) {
	            $settings_link = '<a href="?page=easy-google-login/egl.admin.page.php">Settings</a>';
	            array_unshift($links, $settings_link);
	        }
	        return $links;
	    }
	 	
	 }
     
     add_action("init", "EGL::adminAssets");
     add_filter('plugin_action_links', 'EGL::plugin_action', 10, 2);
	 add_action("wp_head", "EGL::assets");
	 add_action("admin_menu", "EGL::adminMenu");
     add_shortcode('egl-login', 'EGL::EGLloginButton');
     add_action('wp_ajax_EGLlogin', 'EGL::EGLlogin');
     add_action('wp_ajax_nopriv_EGLlogin', 'EGL::EGLlogin');


?>




  


