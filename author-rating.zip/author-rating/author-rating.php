<?php
/*
 * Plugin Name: Author Rating
 * Author:Ravi Khandelwal
 * Version: 1.01
 * Description: Rate your sites user.
 * Author URI: http://www.ravikhandelwal.com/
 * Version: 1.0.2
 *
 * Copyright 2014  Ravi Khandelwal (email : ravi@ravikhandelwal.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @author Ravi Khandelwal
 * @version 1.0.2
 * */




function auth_rating() {
     
    /* ---------------------------------------------------Database Creation---------------------------------------------------------------------- */
    global $wpdb;
    $table_name = $wpdb->prefix . "wp_rating";
    $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `toUser` varchar(255) NOT NULL,
  `fromUsersid` int(10) NOT NULL,
  `rating` int(10) NOT NULL,
  `ratingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8";
   // dbDelta($sql);
    ?>

    <!--------------------------------------------------------Database Part End----------------------------------------------------------------------->

    <!-- -------------------------------------------------Script & Styles----------------------------------------------------------------------------->


    <script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery("input:radio[name=rating]").click(function() {
            if(jQuery(this).val()=='')
                return false;
            //-------------------ajax
            var rate = jQuery(this).val();
            jQuery.ajax({
                type: "POST",
                url: "<?php echo site_url() . ("/wp-admin/admin-ajax.php"); ?>",
                data: {
                    action: "myauthorRating",
                    rate: rate,
                    fromUserId: <?php echo $Fromuser_id; ?>,
                    ToID: 3

                }
            }).done(function(respo) {
                
                alert(respo);



            });


            //------------------Ajax end-----------------------------------//
    

        });
    });

</script>

    <!------------------------------------------Script & Styles Part End------------------------------------------------------------------------->
    <?php
    global $current_user;
    get_currentuserinfo();
    $Fromuser_id = $current_user->ID;
    $firstname = get_user_meta($user_id, "first_name", true);
    $lastname = get_user_meta($user_id, "last_name", true);
    $author = get_user_by('slug', get_query_var('author_name'));
    $authorID = $author->ID;
    ?> 


    
    <div class="styletop">
        <div class="topheaderstyle">
            <div class="topheaderstyleleft">Welcome ! <?php echo $current_user->user_login; ?></div>
            <div><a href="<?php echo wp_logout_url(site_url("/wp-login.php/")); ?>" class="topheaderstyleleftright">Logout</a></div>
        </div>
    </div>
    <?php
    $getRatings = $wpdb->get_var("SELECT SUM(rating) FROM wp_rating WHERE toUser ='$authorID'");
    $getRatingsCOUNT = $wpdb->get_var("SELECT COUNT(rating) FROM wp_rating WHERE toUser ='$authorID'");



    $finalRating = round($getRatings / $getRatingsCOUNT);
    ?>
    <form action="" method="post" id="UserRating">

        <div class="rating">
            <input type="radio" name="rating" value="0" checked /><span id="hide"></span>
            <?php for ($i = 1; $i <= 5; $i++) { ?>

                <input type="radio" name="rating" value="<?php echo $i; ?>" <?php if ($i == $finalRating) echo "checked" ?> /><span></span>

            <?php } ?>
        </div>
        <strong class="choice">Choose a rating</strong>
    </form>
    
    


    <?php
}
add_action('admin_menu', 'author_rating_mains');

function author_rating_mains() {
    add_menu_page('Author Rating', 'Author Rating', 'manage_options', 'authorrating', 'author_rating_callback');
}

function author_rating_callback() {
    
}

function myauthorRating() {

    global $wpdb;
    $rate = $_POST['rate'];
    $Fromuser_id = $_POST['fromUserId'];
    $toUserId = $_POST['ToID'];

    $getFromID = $wpdb->get_col("SELECT fromUsersid FROM wp_rating WHERE toUser =$toUserId", 0);

    if ($getFromID != '' && in_array($Fromuser_id, $getFromID))
        echo '<h2>You have already Rated This user.</h2>';


    else {

        $InsertData = array('toUser' => $toUserId, 'fromUsersid' => $Fromuser_id, 'rating' => $rate, 'status' => 'Y');
        $wpdb->insert('wp_rating', $InsertData);
        echo 'Rated';
    }


    die;
}

add_action('wp_ajax_myauthorRating', 'myauthorRating');
add_action('wp_ajax_nopriv_myauthorRating', 'myauthorRating');

add_shortcode('author-rating', 'auth_rating');
?>