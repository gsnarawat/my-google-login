<?php 

if (isset($_POST['google-login'])) {

    
        update_option('MGLoginPageAfterLogin_id', $_POST['MGLoginPageAfterLogin'], '', 'yes');
        $aflogin = get_permalink($_POST['MGLoginPageAfterLogin']);        
        update_option('MGLoginAppID', $_POST['MGLoginAppID'], '', 'yes');
        update_option('MGLoginPageAfterLogin', $aflogin, '', 'yes');        
        update_option('MGLoginDefaultRole', $_POST['MGLoginDefaultRole'], '', 'yes');
        update_option('MGLoginGetAvatar', $_POST['MGLoginGetAvatar'], '', 'yes');
        $msg = '<div class="updated" id="message"><p>Settings Saved <strong>Successfully!</strong></p></div>';
    
}
?>
<div class="wrap">
    <h2>My Google Login</h2>
    <?php if (isset($msg)) echo $msg; ?>
    <div class="simpleTabs">
        <ul class="simpleTabsNavigation">
            <li><a href="#">Settings</a></li>
            <li><a href="#">How it Works</a></li>        
        </ul>
        <div class="simpleTabsContent">
            <div class="left-col">
                <form method="POST" action="" name="saveClientID">
                    <dl>
                        <dt><?php _e('Google App ClientID:'); ?></dt>
                        <dd>
                            <input type="text" name="MGLoginAppID" value="<?php echo get_option('MGLoginAppID'); ?>"/>
                            <em><?php _e('Please put your Google app Client id.'); ?></em>
                        </dd>

                        <dt><?php _e('Page After Login:'); ?></dt>
                        <dd>
                            <?php printf(wp_dropdown_pages(array('name' => 'MGLoginPageAfterLogin', 'echo' => 0, 'show_option_none' => __('&mdash; Select &mdash;'), 'option_none_value' => '0', 'selected' => get_option('MGLoginPageAfterLogin_id')))); ?>
                            <em><?php _e('Please select page for after login redirection, For "Home Page" leave it unselected.'); ?></em>
                        </dd>
                        
                        <dt><?php _e('Default Role for Google User:'); ?></dt>
                        <dd>
                            <select name="MGLoginDefaultRole" id="MGLoginDefaultRole">
                                <?php wp_dropdown_roles(get_option('MGLoginDefaultRole')); ?>
                            </select>
                            <em><?php _e('Please select a role for new user registration.'); ?></em>
                        </dd>

                        <dt><?php _e('Get User Avatar From Google:'); ?></dt>
                        <dd>
                            <select name="MGLoginGetAvatar" id="MGLoginGetAvatar">                                
                                <option value="no" <?php if (get_option('MGLoginGetAvatar') == 'no') echo "selected"; ?> >No</option>
                                <option value="yes" <?php if (get_option('MGLoginGetAvatar') == 'yes') echo "selected"; ?>> Yes</option>                                
                            </select>
                            <em><?php _e('Please select yes, if you like to use Google image as wordpress profile image'); ?></em>
                        </dd>
                    </dl>

                    <input type="submit" name="google-login" class="button button-primary button-large" value="Save"/>
                </form>
            </div>
           
                    <div style="clear: both;"></div>
            <hr />
            <h3 class="float_left">My Google Login</h3>
           

        </div>
        <div class="simpleTabsContent">

            
            <div style="clear: both;"></div>
            <hr />
            <h3 class="float_left">My Google Login</h3>
           
        </div>
    </div>
</div>