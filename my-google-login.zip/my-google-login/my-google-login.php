<?php

/**
 * Plugin Name: My Google Login
 * Plugin URI: http://google.com/
 * Description: Simple Plugin for Google Authentication and User Registration Process. 
 * Version: 1.0
 * Author: Gopal Singh
 * Author URI: http://google.com
 * License: GPL3
 * Network: true
 * Text Domain: my-google-login
 */
	define('MGLURL', plugins_url('my-google-login/'));

	 class MGL {

		 static function assets(){

		 	wp_enqueue_script("jquery");
		 	$plusonejs = 'https://apis.google.com/js/client:plusone.js';
		    wp_enqueue_script('my-google-login1', $plusonejs);
		    //wp_localize_script( 'my-google-login1', 'MyScriptParams', array('parsetags' => 'explicit') );
		    $myGooglLoginJs = MGLURL . 'assets/js/my-google-login.js';
		    wp_enqueue_script('my-google-login', $myGooglLoginJs);
		    $myclientid = get_option('MGLoginAppID');
		    $afterLogin = get_option('MGLoginPageAfterLogin', site_url('/'));
		    if($afterLogin == '')
		    	$afterLogin = site_url('/');
		    wp_localize_script('my-google-login', 'MGL', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'client_id' => $myclientid,
            'afterLogin' => $afterLogin,
            'nextNonce' => wp_create_nonce('myajax-next-nonce'))
            );

		 }

		 static function MGLlogin(){
		  
		   $nonce = $_POST['nextNonce'];
           if (!wp_verify_nonce($nonce, 'myajax-next-nonce'))
             die('Busted!');

            $user_profile = $_POST['args'];
	        
	        $efl_default_role = get_option('MGLoginDefaultRole', 'subscriber');
	        $save_avatar = get_option('MGLoginGetAvatar', 'no');

	        $userdata = array(
	            'user_login' => $user_profile['Name'],
	            'user_nicename' => $user_profile['Name'],
	            'user_email' => $user_profile['Email'],
	            'display_name' => $user_profile['Name'],
	            'first_name' => $user_profile['Name'],
	            'last_name' => $user_profile['Name'],
	            'role' => $efl_default_role,
	            'user_url' => $user_profile['Image'],
	            'user_pass' => "123456"
	        );

	        $user = get_user_by( 'email', $user_profile['Email'] );


	        if (!$user->ID) {
	            $user_id = wp_insert_user($userdata);
	            wp_set_auth_cookie($user_id);
	        } else {
	            wp_set_auth_cookie($user->ID);
	            $user_id = $user->ID;
	        }
	        if ($save_avatar == 'yes') {
	            echo "dfd";
	            $imgthumb = file_get_contents($user_profile['Image']);
	            $imgfull = file_get_contents($user_profile['Image']);
	            $upload = wp_upload_dir();
	            $upload_dir = $upload['basedir'];
	            $avatar_dir = $upload_dir . '/avatars';

	            if (!is_dir($avatar_dir)) {
	                mkdir($avatar_dir, 0777);
	            }
	            $upload_dir = $upload_dir . '/avatars/' . $user_id;

	            if (!is_dir($upload_dir)) {
	                mkdir($upload_dir, 0777);
	            }
	            $filefull = $upload_dir . '/' . $user_profile['Id'] . '-bpfull.jpg';
	            $filethumb = $upload_dir . '/' . $user_profile['Id'] . '-bpthumb.jpg';

	            file_put_contents($filefull, $imgfull);
	            file_put_contents($filethumb, $imgthumb);
	        }




	        exit;
		 }

		 static function MGLloginButton(){
		    
		    
		 	
            if (!is_user_logged_in()){
             echo '<input type="button" id="MGLloginButton" value="Sign In with Google"/>';	
            }
		 	
		  }

		  static function adminAssets() {
	        if (!strpos($_REQUEST['page'], "mgl.admin.page.php"))
	            return;
	        $easyFacebookTabsJs = MGLURL . 'assets/js/my-google-tabs.js';
	        wp_enqueue_script('my-google-tabs', $easyFacebookTabsJs);

	        $easyFacebookTabsCSS = MGLURL . 'assets/css/my-google-tabs.css';
	        wp_enqueue_style('my-google-tabs', $easyFacebookTabsCSS);
	    }
		  static function adminMenu(){

		   add_plugins_page('My Google Login', 'Google Login settings', 'manage_options', 'my-google-login/mgl.admin.page.php', '');		 	

		 }

		 static function plugin_action($links, $file) {
	        static $my_plugin;
	        if (!$my_plugin) {
	            $my_plugin = plugin_basename(__FILE__);
	        }
	        if ($file == $my_plugin) {
	            $settings_link = '<a href="?page=my-google-login/mgl.admin.page.php">Settings</a>';
	            array_unshift($links, $settings_link);
	        }
	        return $links;
	    }
	 	
	 }
     
     add_action("init", "MGL::adminAssets");
     add_filter('plugin_action_links', 'MGL::plugin_action', 10, 2);
	 add_action("wp_head", "MGL::assets");
	 add_action("admin_menu", "MGL::adminMenu");
     add_shortcode('mgl-login', 'MGL::MGLloginButton');
     add_action('wp_ajax_MGLlogin', 'MGL::MGLlogin');
     add_action('wp_ajax_nopriv_MGLlogin', 'MGL::MGLlogin');


?>




  


